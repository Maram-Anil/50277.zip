//Point of initialization
//call the app.js through require

var app = require('./App');
app();